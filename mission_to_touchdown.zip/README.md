# Mission to Touch Down

A space landing game where you need to safely land your spacecraft on different planets!

## Features

- Multiple planets with different gravity and atmospheric conditions
- Wind effects and atmospheric drag
- Landing pad indicators
- Fuel management
- Visual and numerical feedback for safe landing speeds

## Controls

- ↑ UP ARROW = Fire main engine
- ← LEFT ARROW = Move left
- → RIGHT ARROW = Move right
- SPACE = Deploy parachute (when in atmosphere)
- ESC = Quit game

## How to Play

1. Install Python 3.x from [python.org](https://python.org)
2. Install Pygame by running:
   ```
   pip install pygame
   ```
3. Run the game:
   ```
   python planet_lander.py
   ```

## Requirements

- Python 3.x
- Pygame library

## Game Tips

- Start slow to get a feel for the controls
- The car only turns when moving
- Be careful not to hit the track boundaries
- Try to maintain a steady speed around corners 